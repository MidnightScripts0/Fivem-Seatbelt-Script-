-- Seatbelt + NUI Icon + Loud Beep (Client)
-- B = toggle belt
-- Works for DRIVER (-1) and FRONT PASSENGER (0)

local seatbeltOn = false
local lastSpeed = 0.0
local lastVel = vector3(0.0, 0.0, 0.0)

-- ====== CONFIG ======
local KEY_DEFAULT = "B"
local BEEP_INTERVAL_MS = 2200         -- how often to beep
local BEEP_MIN_SPEED_KMH = 15.0       -- only beep above this speed
local BEEP_VOLUME = 1.0              -- 0.0 - 1.0 (NUI audio)
local EJECT_MIN_SPEED_KMH = 50.0
local EJECT_DECEL_THRESHOLD = 0.25
-- =====================

local function kmh(speed) return speed * 3.6 end

local function notify(msg)
    SetNotificationTextEntry("STRING")
    AddTextComponentString(msg)
    DrawNotification(false, false)
end

local function isFrontSeat(ped, veh)
    return (GetPedInVehicleSeat(veh, -1) == ped) or (GetPedInVehicleSeat(veh, 0) == ped)
end

local function nuiVisible(visible)
    SendNUIMessage({ type = "seatbelt:visible", visible = visible })
end

local function nuiState(on)
    SendNUIMessage({ type = "seatbelt:state", on = on })
end

local function nuiBeep(volume)
    SendNUIMessage({ type = "seatbelt:beep", volume = volume or 1.0 })
end

RegisterCommand("seatbelt", function()
    local ped = PlayerPedId()
    if not IsPedInAnyVehicle(ped, false) then return end

    local veh = GetVehiclePedIsIn(ped, false)
    if veh == 0 then return end
    if not isFrontSeat(ped, veh) then return end

    seatbeltOn = not seatbeltOn
    nuiState(seatbeltOn)

    if seatbeltOn then
        notify("Du bist jetzt angeschnallt")
    else
        notify("Du hast den Gurt gelöst")
    end
end, false)

RegisterKeyMapping("seatbelt", "Anschnallen / Abschnallen", "keyboard", KEY_DEFAULT)

-- Show/hide NUI depending on vehicle + front seat
CreateThread(function()
    while true do
        Wait(250)
        local ped = PlayerPedId()
        if IsPedInAnyVehicle(ped, false) then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and isFrontSeat(ped, veh) then
                nuiVisible(true)
                nuiState(seatbeltOn)
            else
                nuiVisible(false)
            end
        else
            seatbeltOn = false
            lastSpeed = 0.0
            lastVel = vector3(0.0, 0.0, 0.0)
            nuiVisible(false)
        end
    end
end)

-- Loud beep (NUI audio) when driving without belt (driver + passenger)
CreateThread(function()
    while true do
        Wait(BEEP_INTERVAL_MS)

        local ped = PlayerPedId()
        if not IsPedInAnyVehicle(ped, false) then
            seatbeltOn = false
        else
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= 0 and isFrontSeat(ped, veh) then
                local spdKmh = kmh(GetEntitySpeed(veh))
                if (not seatbeltOn) and spdKmh >= BEEP_MIN_SPEED_KMH then
                    nuiBeep(BEEP_VOLUME)
                end
            end
        end
    end
end)

-- Prevent exiting while belt is ON
CreateThread(function()
    while true do
        Wait(0)
        if seatbeltOn then
            DisableControlAction(0, 75, true)  -- disable exit vehicle
            DisableControlAction(27, 75, true)
        end
    end
end)

-- Crash detection + eject for front seats if belt OFF
CreateThread(function()
    while true do
        Wait(50)

        local ped = PlayerPedId()
        if not IsPedInAnyVehicle(ped, false) then
            lastSpeed = 0.0
            lastVel = vector3(0.0, 0.0, 0.0)
        else
            local veh = GetVehiclePedIsIn(ped, false)
            if veh == 0 then goto continue end
            if not isFrontSeat(ped, veh) then goto continue end

            local speed = GetEntitySpeed(veh)
            local speedKmhNow = kmh(speed)
            local speedKmhLast = kmh(lastSpeed)

            if not seatbeltOn
                and speedKmhLast >= EJECT_MIN_SPEED_KMH
                and speedKmhNow < (speedKmhLast * (1.0 - EJECT_DECEL_THRESHOLD))
            then
                local coords = GetEntityCoords(ped)
                local forward = GetEntityForwardVector(veh)
                local newPos = coords + (forward * 2.0)

                SetEntityCoords(ped, newPos.x, newPos.y, newPos.z + 0.3, true, true, true, false)
                SetPedToRagdoll(ped, 1500, 1500, 0, true, true, false)
                ApplyForceToEntity(ped, 1, lastVel.x * 8.0, lastVel.y * 8.0, 1.0, 0.0, 0.0, 0.0, 0, false, true, true, false, true)
            end

            lastSpeed = speed
            lastVel = GetEntityVelocity(veh)
        end

        ::continue::
    end
end)
