const wrap = document.getElementById('wrap');
const icon = document.getElementById('icon');
const beep = document.getElementById('beep');

function setState(on) {
  wrap.classList.remove('hidden');
  icon.classList.toggle('on', on);
  icon.classList.toggle('off', !on);
}

window.addEventListener('message', (e) => {
  const data = e.data;
  if (!data || !data.type) return;

  if (data.type === 'seatbelt:visible') {
    wrap.classList.toggle('hidden', !data.visible);
  }

  if (data.type === 'seatbelt:state') {
    setState(!!data.on);
  }

  if (data.type === 'seatbelt:beep') {
    try {
      // force restart for rapid beeps
      beep.pause();
      beep.currentTime = 0;
      beep.volume = Math.min(1, Math.max(0, data.volume ?? 1));
      beep.play();
    } catch (_) {}
  }
});
