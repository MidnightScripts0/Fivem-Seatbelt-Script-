fx_version 'cerulean'
game 'gta5'

author 'DeinName'
description 'Seatbelt Script mit NUI Icon + lautem Beep (Fahrer & Beifahrer)'
version '1.3.0'

ui_page 'html/index.html'

files {
  'html/index.html',
  'html/style.css',
  'html/script.js',
  'html/beep.wav'
}

client_script 'client.lua'
